#!/bin/bash

mkdir /usr/lib/jvm/
tar -xzf /opt/jdk-8u*-linux-x64.tar.gz -C /usr/lib/jvm/
mv /usr/lib/jvm/jdk1.8.0_* /usr/lib/jvm/java-8-oracle
cp -f /opt/install_jdk8/jdk* /etc/profile.d/
